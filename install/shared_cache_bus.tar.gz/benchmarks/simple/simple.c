int a[100]; 				

int main()
{
	int i,j;

 for(i = 0; i < 100; i++)
   a[i] = a[i] + 10;	
}
