#include <iostream>

int main()
{
	cout << "Hello world";
	return 0;
}
